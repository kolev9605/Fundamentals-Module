﻿namespace HotelBookingSystem.Interfaces
{
    public interface IOutputWriter
    {
        void WriteLine(string msg);

        void Weite(string msg);
    }
}
