﻿namespace HotelBookingSystem.Interfaces
{
    public interface IInputReader
    {
        string ReadLine();
    }
}
