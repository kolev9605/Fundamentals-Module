﻿namespace HotelBookingSystem.Models
{
    public enum Roles
    {
        User,
        VenueAdmin
    }
}
