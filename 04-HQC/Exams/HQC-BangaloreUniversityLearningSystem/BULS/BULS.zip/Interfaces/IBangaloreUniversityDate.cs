﻿namespace BangaloreUniversityLearningSystem.Interfaces
{
    using Data;
    using Models;

    public interface IBangaloreUniversityDate
    {
        UsersRepository UsersRepository { get; }

        IRepository<Course> CoursesRepository { get; }
    }
}