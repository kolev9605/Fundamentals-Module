﻿namespace BangaloreUniversityLearningSystem
{
    public enum Role
    {
        Student,
        Lecturer
    }
}