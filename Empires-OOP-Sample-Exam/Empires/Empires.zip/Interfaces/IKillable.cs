﻿namespace Empires.Interfaces
{
    public interface IKillable
    {
        int Health { get; }
    }
}
