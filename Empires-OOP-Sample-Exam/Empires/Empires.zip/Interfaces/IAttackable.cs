﻿namespace Empires.Interfaces
{
    public interface IAttackable
    {
        int Damage { get; }
    }
}
