﻿namespace Empires.Interfaces
{
    public interface IUnit : IAttackable, IKillable
    {
    }
}
