﻿namespace Empires.Interfaces
{
    public interface IUpdate
    {
        void Update();
    }
}
