﻿namespace Empires.Interfaces
{
    public interface IBuilding : IUnitProducable, IResourceProducable, IUpdate
    {

    }
}