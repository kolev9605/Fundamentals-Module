﻿namespace Empires.Interfaces
{
    interface IInputReader
    {
        string Read();
    }
}
