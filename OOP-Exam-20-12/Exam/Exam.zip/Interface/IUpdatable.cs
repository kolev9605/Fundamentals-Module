﻿namespace Exam.Interface
{
    public interface IUpdatable
    {
        void Update();
    }
}
