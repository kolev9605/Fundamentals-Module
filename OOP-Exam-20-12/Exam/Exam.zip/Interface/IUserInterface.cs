﻿namespace Exam.Interface
{
    public interface IUserInterface : IInputReader, IOutputWriter
    {
    }
}
