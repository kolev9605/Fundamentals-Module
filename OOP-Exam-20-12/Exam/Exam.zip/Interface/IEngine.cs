﻿namespace Exam.Interface
{
    public interface IEngine
    {
        void Run();
    }
}
