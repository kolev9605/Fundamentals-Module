﻿namespace Exam.Interface
{
    public interface IInputReader
    {
        string ReadLine();
    }
}
